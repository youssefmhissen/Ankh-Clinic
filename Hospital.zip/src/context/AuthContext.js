// src/context/AuthContext.jsx
import React, { createContext, useState, useEffect } from "react";
import { getUserByEmail, createUser } from "../services/userService";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // user object
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // load from localStorage
    const s = localStorage.getItem("clinic_auth");
    if (s) {
      try {
        const parsed = JSON.parse(s);
        setUser(parsed.user);
        setToken(parsed.token);
      } catch (e) {
        console.error(e);
      }
    }
    setLoading(false);
  }, []);

  const login = async ({ email, password }) => {
    // since MockAPI has no auth endpoint, we implement local auth:
    const found = await getUserByEmail(email);
    if (!found) {
      throw new Error("User not found");
    }
    if (found.password !== password) {
      throw new Error("Invalid credentials");
    }
    // create a fake token
    const fakeToken = `token_${Math.random().toString(36).substring(2, 15)}`;
    setUser(found);
    setToken(fakeToken);
    localStorage.setItem("clinic_auth", JSON.stringify({ token: fakeToken, user: found }));
    return found;
  };

  const signup = async ({ name, email, password, role }) => {
    // create user in API
    const existing = await getUserByEmail(email);
    if (existing) {
      throw new Error("Email already in use");
    }
    const created = await createUser({ name, email, password, role, reservations: [] });
    const fakeToken = `token_${Math.random().toString(36).substring(2, 15)}`;
    setUser(created);
    setToken(fakeToken);
    localStorage.setItem("clinic_auth", JSON.stringify({ token: fakeToken, user: created }));
    return created;
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("clinic_auth");
  };

  const updateUserState = (updatedUser) => {
    setUser(updatedUser);
    const s = localStorage.getItem("clinic_auth");
    if (s) {
      const parsed = JSON.parse(s);
      parsed.user = updatedUser;
      localStorage.setItem("clinic_auth", JSON.stringify(parsed));
    }
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, signup, logout, updateUserState }}>
      {children}
    </AuthContext.Provider>
  );
};
