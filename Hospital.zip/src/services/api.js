// src/services/api.js
import axios from "axios";

const API_BASE = "https://693564a1fa8e704dafbdaf68.mockapi.io/Users";

const api = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

// request interceptor to attach fake token if present
api.interceptors.request.use((config) => {
  try {
    const stored = localStorage.getItem("clinic_auth");
    if (stored) {
      const { token } = JSON.parse(stored);
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
  } catch (e) {
    // ignore
  }
  return config;
});

export default api;
