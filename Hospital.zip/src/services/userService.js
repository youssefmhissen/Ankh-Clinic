// src/services/userService.js
import api from "./api";
import { v4 as uuidv4 } from "uuid";

/**
 * NOTE: MockAPI uses /Users resource.
 */

export const getAllUsers = async () => {
  const res = await api.get("/");
  return res.data;
};

export const getUserById = async (id) => {
  const res = await api.get(`/${id}`);
  return res.data;
};

export const getUserByEmail = async (email) => {
  const all = await getAllUsers();
  return all.find(u => u.email?.toLowerCase() === email?.toLowerCase()) || null;
};

export const createUser = async (userPayload) => {
  // userPayload should include name, email, password, role
  const res = await api.post("/", userPayload);
  return res.data;
};

export const updateUser = async (id, partial) => {
  const res = await api.put(`/${id}`, partial);
  return res.data;
};

// For reservations: add reservation to patient.reservations (array)
export const addReservationForPatient = async (patientId, { doctorId, date, time, notes = "" }) => {
  const patient = await getUserById(patientId);
  const existing = patient.reservations || [];
  const reservation = {
    id: uuidv4(),
    doctorId,
    date,
    time,
    notes,
    createdAt: new Date().toISOString()
  };
  const updated = { ...patient, reservations: [...existing, reservation] };
  const res = await api.put(`/${patientId}`, updated);
  return res.data;
};

// Get patients assigned to a doctor (doctorId in patient.reservations)
export const getPatientsByDoctorId = async (doctorId) => {
  const all = await getAllUsers();
  const patients = all.filter(u => u.role === "patient" && Array.isArray(u.reservations) && u.reservations.some(r => r.doctorId === doctorId));
  return patients;
};
