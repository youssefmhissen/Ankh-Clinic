// src/routes/ProtectedRoute.jsx
import React, { useContext } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

/**
 * Usage:
 * <Route element={<ProtectedRoute allowedRoles={['patient']} />}>
 *   <Route path="/patient/profile" element={<PatientProfile />} />
 * </Route>
 */
const ProtectedRoute = ({ allowedRoles = [] }) => {
  const { user, loading } = useContext(AuthContext);

  if (loading) return <div className="p-4">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    // redirect to appropriate dashboard
    return <Navigate to={user.role === "doctor" ? "/doctor/profile" : "/patient/profile"} replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
