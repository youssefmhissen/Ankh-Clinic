import logo from './logo.svg';
import './App.css';
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";

// صفحات
import Home from "./pages/Home";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";

import Reservation from "./pages/patient/Reservation";
import PatientProfile from "./pages/patient/PatientProfile";

import DoctorProfile from "./pages/doctor/DoctorProfile";
import PatientsList from "./pages/doctor/PatientsList";

const App = () => {
  return (
    <BrowserRouter>

      <Navbar />

      <Routes>
        {/* Home */}
        <Route path="/" element={<Home />} />

        {/* Auth */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Patient */}
        <Route path="/patient/reservation" element={<Reservation />} />
        <Route path="/patient/profile" element={<PatientProfile />} />

        {/* Doctor */}
        <Route path="/doctor/profile" element={<DoctorProfile />} />
        <Route path="/doctor/patients" element={<PatientsList />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;













// src/App.js

// import React from "react";
// import { BrowserRouter, Routes, Route } from "react-router-dom";

// import Header from "./components/layout/Header";
// import NotFound from "./pages/NotFound";

// // Auth Pages
// import Login from "./pages/auth/Login";
// import Signup from "./pages/auth/Signup";

// // Patient Pages
// import Reservation from "./pages/patient/Reservation";
// import PatientProfile from "./pages/patient/PatientProfile";

// // Doctor Pages
// import DoctorProfile from "./pages/doctor/DoctorProfile";
// import PatientsList from "./pages/doctor/PatientsList";

// // Public Page
// import Home from "./pages/Home";

// // Protected Route
// import ProtectedRoute from "./routes/ProtectedRoute";


// const App = () => {
//   return (
//     <BrowserRouter>
//       <Header />

//       <Routes>
//         {/* ---------------- Public Pages ---------------- */}
//         <Route path="/" element={<Home />} />
//         <Route path="/login" element={<Login />} />

//         <Route path="/signup" element={<Signup />} />

//         {/* ---------------- Patient Only ---------------- */}
//         <Route
//           element={<ProtectedRoute allowedRoles={["patient"]} />}
//         >
//           <Route path="/patient/reservation" element={<Reservation />} />
//           <Route path="/patient/profile" element={<PatientProfile />} />
//         </Route>

//         {/* ---------------- Doctor Only ---------------- */}
//         <Route
//           element={<ProtectedRoute allowedRoles={["doctor"]} />}
//         >
//           <Route path="/doctor/profile" element={<DoctorProfile />} />
//           <Route path="/doctor/patients" element={<PatientsList />} />
//         </Route>

//         {/* ---------------- Not Found ---------------- */}
//         <Route path="*" element={<NotFound />} />
//       </Routes>
//     </BrowserRouter>
//   );
// };

// export default App;

























// src/App.jsx
// src/App.jsx
// import React from "react";
// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Header from "./components/layout/Header";
// import Home from "./pages/Home";
// import Signup from "./pages/auth/Signup";
// import Login from "./pages/auth/Login";
// import PatientProfile from "./pages/patient/PatientProfile";
// import Reservation from "./pages/patient/Reservation";
// import DoctorProfile from "./pages/doctor/DoctorProfile";
// import PatientsList from "./pages/doctor/PatientsList";
// import NotFound from "./pages/NotFound";
// import ProtectedRoute from "./routes/ProtectedRoute";

// function App() {
//   return (
//     <BrowserRouter>
//       <Header />
//       <Routes>
//         <Route path="/" element={<Home />} />

//         <Route path="/signup" element={<Signup />} />
//         <Route path="/login" element={<Login />} />

//         {/* Protected patient routes */}
//         <Route element={<ProtectedRoute allowedRoles={["patient"]} />}>
//           <Route path="/patient/profile" element={<PatientProfile />} />
//           <Route path="/patient/reservation" element={<Reservation />} />
//         </Route>

//         {/* Protected doctor routes */}
//         <Route element={<ProtectedRoute allowedRoles={["doctor"]} />}>
//           <Route path="/doctor/profile" element={<DoctorProfile />} />
//           <Route path="/doctor/patients" element={<PatientsList />} />
//         </Route>

//         <Route path="*" element={<NotFound />} />
//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;


// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
