// src/pages/NotFound.jsx
import React from "react";
import PageContainer from "../components/ui/PageContainer";
import Card from "../components/ui/Card";
import { Link } from "react-router-dom";

const NotFound = () => (
  <PageContainer title="404 - Not Found">
    <Card>
      <p>Page not found.</p>
      <Link to="/" className="text-indigo-600">Go Home</Link>
    </Card>
  </PageContainer>
);

export default NotFound;
