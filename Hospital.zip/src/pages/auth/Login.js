// src/pages/auth/Login.jsx
import React, { useState, useContext } from "react";
import PageContainer from "../../components/ui/PageContainer";
import Input from "../../components/ui/Input";
import Button from "../../components/ui/Button";
import { AuthContext } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const { login } = useContext(AuthContext);
  const nav = useNavigate();

  const onChange = e => setForm(s => ({ ...s, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const u = await login(form);
      if (u.role === "doctor") nav("/doctor/profile");
      else nav("/patient/profile");
    } catch (err) {
      setError(err.message || "Login failed");
    }
  };

  return (
    <PageContainer title="Login">
      <div className="max-w-md">
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow">
          {error && <div className="text-red-600 mb-2">{error}</div>}
          <Input label="Email" name="email" value={form.email} onChange={onChange} type="email" required />
          <Input label="Password" name="password" value={form.password} onChange={onChange} type="password" required />
          <Button type="submit">Login</Button>
        </form>
      </div>
    </PageContainer>
  );
};

export default Login;
