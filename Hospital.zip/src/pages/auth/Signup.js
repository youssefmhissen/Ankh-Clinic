// src/pages/auth/Signup.jsx
import React, { useState, useContext } from "react";
import PageContainer from "../../components/ui/PageContainer";
import Input from "../../components/ui/Input";
import Button from "../../components/ui/Button";
import { AuthContext } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Signup = () => {
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "patient" });
  const [loading, setLoading] = useState(false);
  const { signup } = useContext(AuthContext);
  const nav = useNavigate();
  const [error, setError] = useState("");

  const onChange = e => setForm(s => ({ ...s, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const created = await signup(form);
      // redirect by role
      if (created.role === "doctor") nav("/doctor/profile");
      else nav("/patient/profile");
    } catch (err) {
      setError(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer title="Signup">
      <div className="max-w-md">
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow">
          {error && <div className="text-red-600 mb-2">{error}</div>}
          <Input label="Name" name="name" value={form.name} onChange={onChange} required />
          <Input label="Email" name="email" value={form.email} onChange={onChange} type="email" required />
          <Input label="Password" name="password" value={form.password} onChange={onChange} type="password" required />
          <div className="mb-3">
            <label className="block mb-1">Role</label>
            <select name="role" value={form.role} onChange={onChange} className="w-full px-3 py-2 border rounded">
              <option value="patient">Patient</option>
              <option value="doctor">Doctor</option>
            </select>
          </div>
          <Button type="submit" disabled={loading}>{loading ? "Creating..." : "Signup"}</Button>
        </form>
      </div>
    </PageContainer>
  );
};

export default Signup;
