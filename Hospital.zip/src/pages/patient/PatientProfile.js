import React, { useContext, useState, useEffect } from "react";
import PageContainer from "../../components/ui/PageContainer";
import Card from "../../components/ui/Card";
import Input from "../../components/ui/Input";
import Button from "../../components/ui/Button";
import { AuthContext } from "../../context/AuthContext";
import { updateUser } from "../../services/userService";

const PatientProfile = () => {
  const { user, updateUserState } = useContext(AuthContext);

  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: "", email: "" });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) setForm({ name: user.name || "", email: user.email || "" });
  }, [user]);

  const handleSave = async () => {
    setLoading(true);
    try {
      const updated = await updateUser(user.id, {
        ...user,
        name: form.name,
        email: form.email,
      });

      updateUserState(updated);
      setEditing(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer title="Patient Profile">
      <Card>
        {!editing ? (
          <>
            <div className="mb-3"><strong>Name:</strong> {user?.name}</div>
            <div className="mb-3"><strong>Email:</strong> {user?.email}</div>

            <Button onClick={() => setEditing(true)}>Edit</Button>
          </>
        ) : (
          <>
            <Input label="Name" name="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />

            <Input label="Email" name="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />

            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={loading}>Save</Button>
              <Button className="bg-gray-300 text-black" onClick={() => setEditing(false)}>Cancel</Button>
            </div>
          </>
        )}
      </Card>
    </PageContainer>
  );
};

export default PatientProfile;



























// // src/pages/patient/PatientProfile.jsx
// import React, { useContext, useState, useEffect } from "react";
// import PageContainer from "../../components/ui/PageContainer";
// import Card from "../../components/ui/Card";
// import Input from "../../components/ui/Input";
// import Button from "../../components/ui/Button";
// import { AuthContext } from "../../context/AuthContext";
// import { updateUser, getUserById } from "../../services/userService";

// const PatientProfile = () => {
//   const { user, updateUserState } = useContext(AuthContext);
//   const [editing, setEditing] = useState(false);
//   const [form, setForm] = useState({ name: "", email: "" });
//   const [loading, setLoading] = useState(false);

//   useEffect(() => {
//     if (user) setForm({ name: user.name || "", email: user.email || "" });
//   }, [user]);

//   const onChange = (e) => setForm(s => ({ ...s, [e.target.name]: e.target.value }));

//   const handleSave = async () => {
//     setLoading(true);
//     try {
//       // We patch the user — MockAPI supports PUT/PUT
//       const updated = await updateUser(user.id, { ...user, name: form.name, email: form.email });
//       updateUserState(updated);
//       setEditing(false);
//     } catch (err) {
//       console.error(err);
//       alert("Update failed");
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (!user) return <PageContainer><div>Loading...</div></PageContainer>;

//   return (
//     <PageContainer title="Patient Profile">
//       <Card>
//         {!editing ? (
//           <>
//             <div className="mb-3"><strong>Name: </strong>{user.name}</div>
//             <div className="mb-3"><strong>Email: </strong>{user.email}</div>
//             <Button onClick={() => setEditing(true)}>Edit</Button>
//           </>
//         ) : (
//           <>
//             <Input label="Name" name="name" value={form.name} onChange={onChange} />
//             <Input label="Email" name="email" value={form.email} onChange={onChange} />
//             <div className="flex gap-2">
//               <Button onClick={handleSave} disabled={loading}>Save</Button>
//               <Button onClick={() => setEditing(false)} className="bg-gray-300 text-black">Cancel</Button>
//             </div>
//           </>
//         )}
//       </Card>
//     </PageContainer>
//   );
// };

// export default PatientProfile;
