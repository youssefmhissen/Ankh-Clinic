import React, { useState, useEffect, useContext } from "react";
import PageContainer from "../../components/ui/PageContainer";
import Card from "../../components/ui/Card";
import Input from "../../components/ui/Input";
import Button from "../../components/ui/Button";
import { AuthContext } from "../../context/AuthContext";
import { getAllUsers, addReservationForPatient, getUserById } from "../../services/userService";

const Reservation = () => {
  const { user, updateUserState } = useContext(AuthContext);

  const [doctors, setDoctors] = useState([]);
  const [form, setForm] = useState({ doctorId: "", date: "", time: "", notes: "" });
  const [myReservations, setMyReservations] = useState([]);

  useEffect(() => {
    (async () => {
      const all = await getAllUsers();
      setDoctors(all.filter((u) => u.role === "doctor"));

      if (user) {
        const refreshed = await getUserById(user.id);
        setMyReservations(refreshed.reservations || []);
        updateUserState(refreshed);
      }
    })();
  }, [user, updateUserState]);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();

    const updatedPatient = await addReservationForPatient(user.id, form);

    setMyReservations(updatedPatient.reservations);
    updateUserState(updatedPatient);

    setForm({ doctorId: "", date: "", time: "", notes: "" });
  };

  return (
    <PageContainer title="Make Reservation">
      <div className="grid md:grid-cols-2 gap-6">

        {/* FORM */}
        <Card>
          <form onSubmit={handleSubmit} className="space-y-3">
            <label className="font-medium">Doctor</label>
            <select
              name="doctorId"
              value={form.doctorId}
              onChange={onChange}
              className="w-full p-3 border rounded"
            >
              <option value="">Select doctor</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>

            <Input name="date" label="Date" type="date" value={form.date} onChange={onChange} />
            <Input name="time" label="Time" type="time" value={form.time} onChange={onChange} />
            <Input name="notes" label="Notes" value={form.notes} onChange={onChange} />

            <Button type="submit">Reserve</Button>
          </form>
        </Card>

        {/* LISTS */}
        <div className="space-y-4">
          <Card>
            <h2 className="font-semibold mb-2">Upcoming Reservations</h2>
            {myReservations.length === 0 && <div>No reservations</div>}
            {myReservations.map((r) => (
              <div key={r.id} className="border-b py-2">
                <div><strong>Date:</strong> {r.date} — <strong>Time:</strong> {r.time}</div>
                <div className="text-gray-600">{r.notes}</div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </PageContainer>
  );
};

export default Reservation;




















// import React, { useState, useEffect, useContext } from "react";
// import PageContainer from "../../components/ui/PageContainer";
// import Card from "../../components/ui/Card";
// import Input from "../../components/ui/Input";
// import Button from "../../components/ui/Button";
// import { AuthContext } from "../../context/AuthContext";
// import { getAllUsers, addReservationForPatient } from "../../services/userService";

// const Reservation = () => {
// const { user, updateUserState } = useContext(AuthContext);
// const [doctors, setDoctors] = useState([]);
// const [form, setForm] = useState({
// doctorId: "",
// date: "",
// time: "",
// notes: "",
// });

// useEffect(() => {
// (async () => {
// const all = await getAllUsers();
// setDoctors(all.filter((u) => u.role === "doctor"));
// })();
// }, []);

// const onChange = (e) =>
// setForm((s) => ({ ...s, [e.target.name]: e.target.value }));

// const submit = async (e) => {
// e.preventDefault();
// const updated = await addReservationForPatient(user.id, form);
// updateUserState(updated);
// setForm({ doctorId: "", date: "", time: "", notes: "" });
// };

// return ( 
// <PageContainer title="Make Reservation"> <div className="grid md:grid-cols-2 gap-6"> <Card> <form onSubmit={submit} className="space-y-4">
// {/* Doctor Select */} <div> <label className="block font-medium mb-1">Doctor</label> <select
//              name="doctorId"
//              value={form.doctorId}
//              onChange={onChange}
//              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
//            > <option value="">Select doctor</option>
// {doctors.map((d) => ( <option key={d.id} value={d.id}>
// {d.name} — {d.speciality || "General"} </option>
// ))} </select> </div>

// ```
//         <Input name="date" label="Date" type="date" value={form.date} onChange={onChange} />

//         <Input name="time" label="Time" type="time" value={form.time} onChange={onChange} />

//         <Input name="notes" label="Notes" placeholder="Add notes..." value={form.notes} onChange={onChange} />

//         <Button type="submit">Reserve</Button>
//       </form>
//     </Card>
//   </div>
// </PageContainer>
// ```
// )
// );
// };

// export default Reservation;



// src/pages/patient/Reservation.jsx
// import React, { useState, useEffect, useContext } from "react";
// import PageContainer from "../../components/ui/PageContainer";
// import Card from "../../components/ui/Card";
// import Input from "../../components/ui/Input";
// import Button from "../../components/ui/Button";
// import { AuthContext } from "../../context/AuthContext";
// import { getAllUsers, addReservationForPatient, getUserById } from "../../services/userService";
// import { Link } from "react-router-dom";

// const Reservation = () => {
//   const { user, updateUserState } = useContext(AuthContext);
//   const [doctors, setDoctors] = useState([]);
//   const [form, setForm] = useState({ doctorId: "", date: "", time: "", notes: "" });
//   const [loading, setLoading] = useState(false);
//   const [myReservations, setMyReservations] = useState([]);

//   useEffect(() => {
//     (async () => {
//       const all = await getAllUsers();
//       setDoctors(all.filter(u => u.role === "doctor"));
//       if (user) {
//         const refreshed = await getUserById(user.id);
//         setMyReservations(refreshed.reservations || []);
//         updateUserState(refreshed);
//       }
//     })();
//   }, [user, updateUserState]);

//   const onChange = e => setForm(s => ({ ...s, [e.target.name]: e.target.value }));

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!form.doctorId || !form.date || !form.time) return alert("Please fill all");
//     setLoading(true);
//     try {
//       const updatedPatient = await addReservationForPatient(user.id, {
//         doctorId: form.doctorId,
//         date: form.date,
//         time: form.time,
//         notes: form.notes
//       });
//       setMyReservations(updatedPatient.reservations || []);
//       updateUserState(updatedPatient);
//       setForm({ doctorId: "", date: "", time: "", notes: "" });
//     } catch (err) {
//       console.error(err);
//       alert("Failed to add reservation");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const upcoming = myReservations.filter(r => new Date(r.date) >= new Date()).sort((a,b) => new Date(a.date) - new Date(b.date));
//   const previous = myReservations.filter(r => new Date(r.date) < new Date()).sort((a,b) => new Date(b.date) - new Date(a.date));

//   return (
//     <PageContainer title="Make Reservation">
//       <div className="grid md:grid-cols-2 gap-4">
//         <Card>
//           <form onSubmit={handleSubmit}>
//             <label className="block mb-1">Doctor</label>
//             <select name="doctorId" value={form.doctorId} onChange={onChange} className="w-full mb-3 p-2 border rounded">
//               <option value="">Select doctor</option>
//               {doctors.map(d => <option value={d.id} key={d.id}>{d.name} - {d.speciality || "General"}</option>)}
//             </select>
//             <Input label="Date" name="date" type="date" value={form.date} onChange={onChange} />
//             <Input label="Time" name="time" type="time" value={form.time} onChange={onChange} />
//             <Input label="Notes" name="notes" value={form.notes} onChange={onChange} />
//             <Button type="submit" disabled={loading}>Reserve</Button>
//           </form>
//         </Card>

//         <div>
//           <Card className="mb-4">
//             <h3 className="font-semibold mb-2">Upcoming</h3>
//             {upcoming.length === 0 && <div>No upcoming reservations</div>}
//             {upcoming.map(r => (
//               <div key={r.id} className="border-b py-2">
//                 <div><strong>Date:</strong> {r.date} <strong>Time:</strong> {r.time}</div>
//                 <div><strong>Doctor:</strong> {doctors.find(d => d.id === r.doctorId)?.name || r.doctorId}</div>
//                 <div className="text-sm text-gray-600">{r.notes}</div>
//               </div>
//             ))}
//           </Card>

//           <Card>
//             <h3 className="font-semibold mb-2">Previous</h3>
//             {previous.length === 0 && <div>No previous reservations</div>}
//             {previous.map(r => (
//               <div key={r.id} className="border-b py-2">
//                 <div><strong>Date:</strong> {r.date} <strong>Time:</strong> {r.time}</div>
//                 <div><strong>Doctor:</strong> {doctors.find(d => d.id === r.doctorId)?.name || r.doctorId}</div>
//                 <div className="text-sm text-gray-600">{r.notes}</div>
//               </div>
//             ))}
//           </Card>
//         </div>
//       </div>
//     </PageContainer>
//   );
// };

// export default Reservation;
