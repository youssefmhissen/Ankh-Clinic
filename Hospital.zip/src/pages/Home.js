// src/pages/Home.jsx
import React from "react";
import PageContainer from "../components/ui/PageContainer";
import Card from "../components/ui/Card";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <PageContainer title="Welcome to ANKH Clinic">
      <Card>
        <p className="mb-3">A simple demo to manage patients and doctors using MockAPI.</p>
        <div className="flex gap-3">
          <Link to="/signup" className="px-4 py-2 rounded bg-green-600 text-white">Create account</Link>
          <Link to="/login" className="px-4 py-2 rounded bg-indigo-600 text-white">Login</Link>
        </div>
      </Card>
    </PageContainer>
  );
};

export default Home;
