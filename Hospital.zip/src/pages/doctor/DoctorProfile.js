import React, { useContext } from "react";
import PageContainer from "../../components/ui/PageContainer";
import Card from "../../components/ui/Card";
import { AuthContext } from "../../context/AuthContext";
import { Link } from "react-router-dom";

const DoctorProfile = () => {
  const { user } = useContext(AuthContext);

  return (
    <PageContainer title="Doctor Profile">
      <Card>
        <div className="mb-3"><strong>Name:</strong> {user?.name}</div>
        <div className="mb-3"><strong>Email:</strong> {user?.email}</div>
        <div className="mb-3"><strong>Speciality:</strong> {user?.speciality || "General"}</div>

        <Link to="/doctor/patients" className="text-indigo-600 font-medium underline">
          View My Patients
        </Link>
      </Card>
    </PageContainer>
  );
};

export default DoctorProfile;














// // src/pages/doctor/DoctorProfile.jsx
// import React, { useContext } from "react";
// import PageContainer from "../../components/ui/PageContainer";
// import Card from "../../components/ui/Card";
// import { AuthContext } from "../../context/AuthContext";
// import { Link } from "react-router-dom";

// const DoctorProfile = () => {
//   const { user } = useContext(AuthContext);

//   return (
//     <PageContainer title="Doctor Profile">
//       <Card>
//         <div className="mb-2"><strong>Name: </strong>{user?.name}</div>
//         <div className="mb-2"><strong>Email: </strong>{user?.email}</div>
//         <div className="mb-2"><strong>Speciality: </strong>{user?.speciality || "General"}</div>
//         <Link to="/doctor/patients" className="text-indigo-600">View my patients</Link>
//       </Card>
//     </PageContainer>
//   );
// };

// export default DoctorProfile;
