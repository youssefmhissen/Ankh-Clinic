import React, { useEffect, useState, useContext } from "react";
import PageContainer from "../../components/ui/PageContainer";
import Card from "../../components/ui/Card";
import { getPatientsByDoctorId } from "../../services/userService";
import { AuthContext } from "../../context/AuthContext";

const PatientsList = () => {
  const { user } = useContext(AuthContext);
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    (async () => {
      if (!user) return;
      const p = await getPatientsByDoctorId(user.id);
      setPatients(p);
    })();
  }, [user]);

  return (
    <PageContainer title="My Patients">
      <div className="space-y-4">
        {patients.length === 0 && (
          <Card>No patients have reservations for you yet.</Card>
        )}

        {patients.map((p) => (
          <Card key={p.id}>
            <div className="flex justify-between">
              <div>
                <div className="font-bold text-lg">{p.name}</div>
                <div className="text-gray-600 text-sm">{p.email}</div>
              </div>

              <div className="text-sm">
                <strong>Reservations:</strong>
                {p.reservations
                  ?.filter((r) => r.doctorId === user.id)
                  .map((r) => (
                    <div key={r.id} className="mt-1 border-t pt-2">
                      <div><strong>Date:</strong> {r.date} — <strong>Time:</strong> {r.time}</div>
                      <div className="text-gray-600">{r.notes}</div>
                    </div>
                  ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </PageContainer>
  );
};

export default PatientsList;

















// // src/pages/doctor/PatientsList.jsx
// import React, { useEffect, useState, useContext } from "react";
// import PageContainer from "../../components/ui/PageContainer";
// import Card from "../../components/ui/Card";
// import { getPatientsByDoctorId } from "../../services/userService";
// import { AuthContext } from "../../context/AuthContext";

// const PatientsList = () => {
//   const { user } = useContext(AuthContext);
//   const [patients, setPatients] = useState([]);

//   useEffect(() => {
//     (async () => {
//       if (!user) return;
//       const p = await getPatientsByDoctorId(user.id);
//       setPatients(p);
//     })();
//   }, [user]);

//   return (
//     <PageContainer title="My Patients">
//       <div className="space-y-3">
//         {patients.length === 0 && <Card>No patients with reservations for you yet.</Card>}
//         {patients.map(p => (
//           <Card key={p.id}>
//             <div className="flex justify-between items-center">
//               <div>
//                 <div className="font-semibold">{p.name}</div>
//                 <div className="text-sm text-gray-600">{p.email}</div>
//               </div>
//               <div className="text-sm">
//                 <div className="font-semibold">Reservations for you:</div>
//                 {p.reservations?.filter(r => r.doctorId === user.id).map(r => (
//                   <div key={r.id} className="mt-1">
//                     <div><strong>Date:</strong> {r.date} <strong>Time:</strong> {r.time}</div>
//                     <div className="text-sm text-gray-600">{r.notes}</div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           </Card>
//         ))}
//       </div>
//     </PageContainer>
//   );
// };

// export default PatientsList;
