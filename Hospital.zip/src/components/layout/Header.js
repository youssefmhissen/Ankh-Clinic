// src/components/layout/Header.jsx
import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";

const Header = () => {
  const { user, logout } = useContext(AuthContext);
  const nav = useNavigate();

  const handleLogout = () => {
    logout();
    nav("/login");
  };

  return (
    <header className="bg-white shadow">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-xl font-bold text-indigo-600">ANKH Clinic</Link>
        <nav className="flex items-center gap-3">
          <Link to="/" className="px-3 py-1">Home</Link>
          {!user && <Link to="/login" className="px-3 py-1">Login</Link>}
          {!user && <Link to="/signup" className="px-3 py-1">Signup</Link>}
          {user && user.role === "patient" && <Link to="/patient/profile" className="px-3 py-1">My Profile</Link>}
          {user && user.role === "doctor" && <Link to="/doctor/profile" className="px-3 py-1">Doctor Profile</Link>}
          {user ? (
            <>
              <span className="px-3 py-1 text-sm text-gray-600">Hi, {user.name}</span>
              <button onClick={handleLogout} className="text-sm text-red-500">Logout</button>
            </>
          ) : null}
        </nav>
      </div>
    </header>
  );
};

export default Header;
