import React from "react";

export default function Footer() {
  return (
    <footer className="w-full bg-gray-900 text-white py-6 mt-10">
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
        
        {/* Logo */}
        <h2 className="text-xl font-semibold tracking-wide">HealthCare System</h2>

        {/* Links */}
        <div className="flex gap-6 mt-4 md:mt-0">
          <a href="/" className="hover:text-blue-400 transition">Home</a>
          <a href="/about" className="hover:text-blue-400 transition">About</a>
          <a href="/login" className="hover:text-blue-400 transition">Login</a>
        </div>

        {/* Copyright */}
        <p className="text-sm mt-4 md:mt-0 opacity-75">
          © {new Date().getFullYear()} All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
