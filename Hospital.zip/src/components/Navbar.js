import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-blue-600 text-white px-6 py-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">

        {/* Logo */}
        <h1 className="text-xl font-bold">
          <Link to="/">Clinic System</Link>
        </h1>

        {/* Navigation Links */}
        <ul className="flex gap-6">

          <li className="hover:text-yellow-300">
            <Link to="/">Home</Link>
          </li>

          <li className="hover:text-yellow-300">
            <Link to="/patient/reservation">Reservation</Link>
          </li>

          <li className="hover:text-yellow-300">
            <Link to="/patient/profile">Patient Profile</Link>
          </li>

          <li className="hover:text-yellow-300">
            <Link to="/doctor/profile">Doctor Profile</Link>
          </li>

          <li className="hover:text-yellow-300">
            <Link to="/doctor/patients">Patients List</Link>
          </li>

        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
