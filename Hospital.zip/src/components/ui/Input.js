// src/components/ui/Input.jsx
import React from "react";

const Input = ({ label, ...props }) => {
  return (
    <div className="mb-3">
      {label && <label className="block text-sm mb-1">{label}</label>}
      <input
        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-200"
        {...props}
      />
    </div>
  );
};

export default Input;
