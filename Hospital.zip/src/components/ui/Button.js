// src/components/ui/Button.jsx
import React from "react";

const Button = ({ children, onClick, type = "button", className = "", ...rest }) => {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`px-4 py-2 rounded-md shadow-sm bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-60 ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
};

export default Button;
