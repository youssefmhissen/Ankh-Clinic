// src/components/ui/PageContainer.jsx
import React from "react";

const PageContainer = ({ children, title }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto p-6">
        {title && <h1 className="text-2xl font-semibold mb-4">{title}</h1>}
        {children}
      </div>
    </div>
  );
};

export default PageContainer;
